const express = require('express')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const User = require('../models/signUpModel')

const getLogin = (req, res)=>{

    res.render('log-in')
}

const getSignup = (req, res)=>{

    res.render('sign-up')
}

const postSignup = (req, res)=>{
    const firstname = req.body.fname
    const lastname = req.body.lname
    const email = req.body.email
    const password = req.body.pword

    User.create({
        firstname: firstname,
        lastname: lastname,
        email: email,
        password: password
    })

    res.redirect('/login')
}

const postLogin = async (req, res)=> {
    const claimedEmail = req.body.email
    const claimedPassword = req.body.pword
    const foundEmail = await User.findOne({email: claimedEmail})
    const foundPassword = await User.findOne({password: claimedPassword})

    if(foundEmail && foundPassword){
       const foundUserId = foundEmail._id

        const token = jwt.sign({ foundUserId }, 'scatteringUserToken', { expiresIn: '34560004000' })
        res.cookie('auth', token, { maxAge: 34560004000 })
       
       res.render('log-in', {message: 'you are logged in'})
    }else{
            res.render('log-in', { error: 'Incorrect Credentials' })
    }


}


module.exports = {getSignup, getLogin, postSignup, postLogin}