const express = require('express')
const bcrypt = require('bcrypt')
const mongoose = require('mongoose')
const jwt = require('jsonwebtoken')
const cookieparser = require('cookie-parser')


mongoose.connect('mongodb://127.0.0.1:27017/commerce').then(()=>{
    console.log('db connected')
}).catch((err)=>{
console.log(err)
})
const app = express()
const exphbs = require('express-handlebars')

app.engine('hbs', exphbs.engine({
    extname: '.hbs', defaultLayout: 'main', runtimeOptions:{
        allowProtoMethodsByDefault: true,
        allowProtoPropertiesByDefault: true
    }
}))
app.set('view engine', 'hbs' )

app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(express.static('public'))
app.use(cookieparser())



const homePage = require('./routes/homeRoutes')

app.use('/', homePage )



app.listen(4000, ()=>{
    console.log('port 4000 is running')
})