const express = require('express')
const routes = express.Router()
const {getLogin, getSignup, postSignup, postLogin} = require('../controllers/homeControllers')

routes.get('/login', getLogin)
routes.get('/signup', getSignup)

routes.post('/signup', postSignup)
routes.post('/login', postLogin)


module.exports = routes