const express = require('express')
const mongoose = require('mongoose')

const userSignUpModel = new mongoose.Schema({
    firstname: {
        type: String
    },
    lastname: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    }
})

const User = new mongoose.model('User', userSignUpModel)

module.exports=User